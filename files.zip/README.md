# Gemelo Digital de Procesos Alimentarios

Simulación en tiempo real de pasteurización HTST y fermentación láctica, con motor cinético basado en la ecuación de Arrhenius, emulación de sensores IoT y tablero de operador con alarmas HACCP.

Proyecto integrador de Química I · Ingeniería de Alimentos + Ingeniería de Sistemas.

---

## 1. Arquitectura del sistema

### 1.1 Reparto de responsabilidades

El punto de contacto entre las dos carreras es **`backend/config.py`**. Ahí viven todas las constantes fisicoquímicas y los límites críticos; ningún otro archivo contiene números sueltos. Tu compañero de Alimentos puede ajustar energías de activación, valores D y z, capacidad tampón o límites de PCC sin tocar una sola línea de lógica de software, y tú puedes refactorizar el backend sin alterar la química.

| Módulo | Responsable | Qué contiene |
|---|---|---|
| `config.py` | Alimentos (datos) + Sistemas (estructura) | Constantes, perfiles de proceso, límites PCC |
| `chemistry.py` | Alimentos valida, Sistemas implementa | Arrhenius, ley de velocidad, balances, equilibrio ácido-base |
| `alerts.py` | Alimentos define, Sistemas implementa | Evaluación HACCP, histéresis, acciones correctivas |
| `simulator.py` | Sistemas | Hilo de tiempo real, sensores con ruido, buffer de historia |
| `app.py` | Sistemas | API REST + WebSocket |
| `frontend/index.html` | Sistemas | Tablero de operador |
| `tests/` | Ambos | Verificación contra soluciones analíticas |

### 1.2 Diagrama de arquitectura

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                          NAVEGADOR (cliente)                                 │
│                                                                              │
│   frontend/index.html                                                        │
│   ┌────────────────┐  ┌──────────────────────────────────────────────────┐   │
│   │  Controles     │  │  Chart.js — 4 gráficas a 1 Hz                    │   │
│   │  · T objetivo  │  │   [A] y [B] vs t · T vs t · pH vs t · P vs t     │   │
│   │  · pH inicial  │  ├──────────────────────────────────────────────────┤   │
│   │  · [A] inicial │  │  Lecturas numéricas + banda de alarmas PCC        │   │
│   │  · velocidad   │  └──────────────────────────────────────────────────┘   │
│   └───────┬────────┘                          ▲                              │
└───────────┼───────────────────────────────────┼──────────────────────────────┘
            │  POST /api/setpoints              │  WebSocket  ws://…/ws/telemetry
            │  (JSON, bajo demanda)             │  (JSON push, 1 trama/segundo)
            ▼                                   │
┌───────────────────────────────────────────────┼──────────────────────────────┐
│                       SERVIDOR — FastAPI + Uvicorn (app.py)                  │
│                                               │                              │
│   REST                                   fan-out a suscriptores              │
│   ├─ GET  /api/state                     asyncio.Queue por cliente           │
│   ├─ GET  /api/history                        ▲                              │
│   ├─ GET  /api/profile                        │ call_soon_threadsafe()       │
│   ├─ GET  /api/deviations                     │                              │
│   ├─ POST /api/setpoints ─────────┐           │                              │
│   └─ POST /api/control/{start|stop|reset}     │                              │
│                                   │           │                              │
│  ═════════ frontera entre el event loop y el hilo de simulación ═══════════  │
│                                   ▼           │                              │
│   MÓDULO DE SIMULACIÓN (simulator.py) — threading.Thread, tick = 1 s         │
│   ┌──────────────────────────────────────────────────────────────────────┐   │
│   │  y = [C_A, C_B, C_HA, T, N, F]      ← estado del gemelo               │   │
│   │      │                                                               │   │
│   │      ├─► chemistry.step()  ── SciPy solve_ivp (LSODA, sistema rígido) │   │
│   │      │       ├─ arrhenius()        k = A·exp(-Ea/RT)                  │   │
│   │      │       ├─ reaction_rate()    r = k·[A]^n                        │   │
│   │      │       ├─ balance de energía m·cp·dT/dt = Q_cam + Q_rxn − Q_p   │   │
│   │      │       ├─ ph_from_weak_acid()  pH = pH0 − C_HA/β                │   │
│   │      │       └─ system_pressure()    Dalton + Antoine + gas ideal     │   │
│   │      │                                                               │   │
│   │      ├─► SensorArray.read()  ── lectura = verdad + N(0,σ) + deriva    │   │
│   │      │                                                               │   │
│   │      ├─► AlertEngine.evaluate()  ── PCC-1 T · PCC-2 pH · PCC-3 P      │   │
│   │      │                               con histéresis anti-parpadeo     │   │
│   │      │                                                               │   │
│   │      └─► deque(maxlen=1800)  ── buffer circular de 30 min             │   │
│   └──────────────────────────────────────────────────────────────────────┘   │
│                                   │                                          │
│                                   ▼                                          │
│                     config.py — constantes y límites PCC                     │
│                     (única fuente de verdad fisicoquímica)                   │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 1.3 Por qué WebSocket y no REST con *polling*

Un gemelo digital emite datos continuamente y el cliente no sabe cuándo llegan. Con *polling* cada navegador abriría una conexión HTTP por segundo, con su handshake, sus cabeceras y una latencia de hasta 1 s en el peor caso. El WebSocket mantiene un único socket abierto y el servidor empuja la trama en cuanto existe.

Los `POST /api/setpoints` sí van por REST: son eventos esporádicos disparados por el usuario, no un flujo. Es el patrón industrial habitual: **telemetría por push, comandos por request/response**. Los endpoints REST de lectura (`/api/state`, `/api/history`) existen como respaldo por si el WebSocket cae o si el profesor quiere consultar la API desde Postman.

### 1.4 Decisiones de diseño defendibles en la sustentación

Cuatro puntos que distinguen esto de un script que dibuja una exponencial:

**El integrador es LSODA, no Euler.** El sistema es rígido: la inactivación microbiana a 72 °C tiene una constante de tiempo de segundos, mientras el tanque tarda minutos en calentarse. Un Euler explícito con Δt = 1 s diverge. LSODA detecta la rigidez y conmuta entre Adams y BDF automáticamente.

**Las alarmas se evalúan contra la lectura del sensor, no contra la verdad del modelo.** Un sistema de control real sólo conoce lo que mide. Evaluar contra el valor exacto sería hacer trampa y ocultaría el problema que de verdad importa: qué pasa cuando el ruido del sensor cruza un umbral.

**Los PCC se arman por fase.** Durante el calentamiento la leche está a 8 °C, y eso no es una desviación: el producto todavía no llegó al tubo de retención. Sin esta lógica el tablero arranca en rojo y el operario aprende a ignorarlo. Los PCC se activan cuando la temperatura entra por primera vez en la banda de operación, y a partir de ahí no se desarman.

**Hay histéresis en las alarmas.** Una variable que oscila justo sobre el umbral generaría decenas de eventos por minuto. La alarma sólo se limpia cuando la variable se recupera con un margen del 8 % de la banda. Es la razón número uno por la que los tableros industriales reales acaban silenciados.

---

## 2. Esquema de datos en tiempo real

Cada segundo el simulador emite una trama JSON. El WebSocket la envuelve en `{"type": ..., "payload": ...}`, con tres tipos: `snapshot` (estado actual, al conectar), `history` (lista de tramas, para repoblar las gráficas) y `telemetry` (trama nueva).

Ejemplo real capturado del sistema (`docs/trama_ejemplo.json`):

```json
{
  "schema_version": "1.1",
  "batch_id": "LOTE-20260918-021641",
  "process": "pasteurizacion",
  "process_label": "Pasteurización HTST de leche entera",
  "seq": 4,
  "timestamp_utc": "2026-09-18T02:16:44.932+00:00",
  "t_process_s": 240.0,

  "readings": {
    "temperature_C": 68.43712,
    "pH": 6.72327,
    "pressure_kPa": 152.79846,
    "concentration_A": 0.13914,
    "concentration_B": 0.00054
  },
  "truth": {
    "temperature_C": 68.37213,
    "pH": 6.69923,
    "pressure_kPa": 152.04403,
    "concentration_A": 0.13945,
    "concentration_B": 0.00054
  },

  "state": {
    "concentration_A": 0.139448,
    "concentration_B": 0.000543,
    "concentration_HA": 3.9e-05,
    "temperature_K": 341.522,
    "microbial_count": 455400.0,
    "lethality_F_s": 5.593
  },
  "metrics": {
    "k_rate_s": 6.9053e-05,
    "conversion": 0.0039,
    "log_reduction": 0.342,
    "lethality_progress": 0.3729,
    "half_life_s": 10038.0
  },
  "control": {
    "setpoint_C": 72.0,
    "jacket_C": 95.0,
    "speed_factor": 60.0,
    "running": true
  },

  "phase": "CALENTAMIENTO",
  "ccp_armed": false,
  "status": "CALENTAMIENTO",
  "alerts": []
}
```

### 2.1 Diccionario de campos

| Campo | Tipo | Significado |
|---|---|---|
| `schema_version` | string | Versión del contrato. Si cambia la estructura, súbela. |
| `batch_id` | string | Identificador del lote, se renueva al pulsar "Nuevo lote". |
| `seq` | int | Número de tick. Sirve para detectar tramas perdidas. |
| `t_process_s` | float | Tiempo de proceso simulado, en segundos. No es tiempo real. |
| `readings` | objeto | **Lo que mide el sensor**: verdad + ruido gaussiano + deriva. |
| `truth` | objeto | **Lo que dice el modelo**, sin ruido. Sólo para validar; un sistema real no lo tendría. |
| `state` | objeto | Vector de estado completo, incluida la letalidad acumulada F. |
| `metrics` | objeto | Indicadores derivados: k(T), conversión, reducción logarítmica, t½. |
| `control` | objeto | Consignas vigentes y estado del lazo. |
| `phase` | string | `CALENTAMIENTO` o `PROCESO`. |
| `status` | string | `CALENTAMIENTO`, `OK`, `WARNING` o `CRITICAL`. |
| `alerts` | lista | Una entrada por PCC en desviación, con acción correctiva. |

La distinción entre `readings` y `truth` es lo que convierte esto en un gemelo digital y no en una gráfica de ecuaciones: permite mostrarle al profesor la diferencia entre lo que ocurre en el proceso y lo que la instrumentación alcanza a ver.

### 2.2 Estructura de una alerta

```json
{
  "ccp_id": "PCC-1",
  "variable": "temperature_C",
  "level": "CRITICAL",
  "value": 69.8,
  "unit": "°C",
  "limit_low": 71.0,
  "limit_high": 78.0,
  "message": "PCC-1: temperature_C = 69.80 °C, por debajo de 71.00 °C.",
  "corrective_action": "Desviar el flujo a la válvula de retorno y recircular hasta recuperar el set point. El producto no puede pasar a llenado."
}
```

---

## 3. El modelo químico

### 3.1 Sistema de ecuaciones

Vector de estado `y = [C_A, C_B, C_HA, T, N, F]`:

```
dC_A/dt  = −(r_principal + r_ácida)                  balance de materia de A
dC_B/dt  = +r_principal                              producto principal
dC_HA/dt = +ν · r_ácida                              ácido generado (ν = 4)
dT/dt    = (Q_camisa + Q_reacción − Q_pérdidas)/(m·cp)   balance de energía
dN/dt    = −k_micro(T) · N                           inactivación térmica
dF/dt    = 10^((T − T_ref)/z)                        letalidad acumulada
```

con

```
r      = k(T) · [A]^n                       ley de velocidad, orden n
k(T)   = A · exp(−Ea / (R·T))               ecuación de Arrhenius
Q_cam  = UA · (T_camisa − T)                transferencia desde la camisa
Q_rxn  = (−ΔH) · r · V                      calor de reacción
Q_pér  = UA_pérdidas · (T − T_ambiente)     pérdidas al ambiente
pH     = max( pH0 − C_HA/β , pH_ácido_libre )
P      = P_aire(T) + P_vapor(T) + P_gas     ley de Dalton
```

### 3.2 El puente entre Química I y microbiología de alimentos

La industria alimentaria no habla de Ea y A, habla de valores D y z. Son el mismo modelo en otra notación, y la función `arrhenius_from_D_z()` hace la conversión:

```
k_ref = ln(10) / D_ref
Ea    = 2.303 · R · T_ref · (T_ref + z) / z
A     = k_ref · exp(Ea / (R · T_ref))
```

Para leche con D₇₂ = 15 s y z = 6.5 °C sale **Ea ≈ 357 kJ/mol**, un valor típico de destrucción térmica de microorganismos. El test `test_valor_z_se_respeta` comprueba que subir z grados multiplica k por 10, que es la definición misma del valor z.

### 3.3 La trampa del pH

Un modelo ingenuo calcula el pH sólo con el equilibrio del ácido débil y predice **pH 2.4** para un yogur que en realidad está en **4.4**. El error es ignorar que la leche es un sistema tamponado: caseínas, fosfatos y citratos captan protones.

El modelo usa la capacidad tampón β = 0.050 mol/(L·pH), que es el valor medido para la leche y se verifica así: 0.10 mol/L de ácido láctico ÷ 2.2 unidades de caída ≈ 0.045 mol/(L·pH). El equilibrio de disociación sigue presente como **piso**: cuando el tampón se agota, manda la química del ácido libre.

### 3.4 Resultados de validación

Corriendo el modelo sin ruido:

**Pasteurización HTST** — el producto llega a 71.9 °C en 5 min, alcanza **5 reducciones logarítmicas antes de los 6 min**, la letalidad F supera los 15 s objetivo y el pH se mantiene en 6.70 ± 0.02. Es exactamente el comportamiento que exige la norma.

**Fermentación de yogur** — el pH baja de 6.60 a **4.68 en 4.5 h**, que es el punto de corte industrial (punto isoeléctrico de la caseína). La curva es gradual, no un escalón, porque el tampón la sostiene.

---

## 4. Instalación y ejecución

### 4.1 Requisitos

Python 3.10 o superior. Comprueba con `python --version`.

### 4.2 Entorno virtual e instalación

**Linux / macOS**

```bash
cd gemelo-digital-quimica
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

**Windows (PowerShell)**

```powershell
cd gemelo-digital-quimica
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install --upgrade pip
pip install -r requirements.txt
```

Si PowerShell bloquea el script de activación:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

### 4.3 Verificar que el modelo es correcto

Antes de levantar nada, ejecuta las pruebas. Validan el motor contra las soluciones analíticas que tu compañero puede resolver a mano:

```bash
pytest -v
```

Deben pasar las 20. Si alguna falla, el problema está en la química, no en la red.

### 4.4 Opción A — Sistema completo (FastAPI + WebSocket)

Es la versión para entregar y sustentar.

```bash
cd backend
uvicorn app:app --reload --port 8000
```

Abre **http://localhost:8000**. El tablero se conecta solo por WebSocket; el indicador de la esquina superior derecha se pone verde.

Documentación interactiva de la API, útil para mostrarle los endpoints al profesor: **http://localhost:8000/docs**

### 4.5 Opción B — Ruta rápida (Streamlit)

Misma física, sin JavaScript. Sirve como plan B si falla algo el día de la presentación.

```bash
streamlit run streamlit_app.py
```

Abre en **http://localhost:8501**.

### 4.6 Probar sólo el motor, sin servidor

```bash
cd backend
python simulator.py
```

Imprime una lectura por segundo en la terminal. Útil para depurar la química sin meter la red de por medio.

---

## 5. Guion de demostración

Cinco minutos que muestran todo lo que el proyecto sabe hacer:

**1. Arranque en frío.** Levanta el sistema y observa la fase `CALENTAMIENTO`. Señala que las alarmas están desarmadas a propósito: el producto a 8 °C no es una desviación, todavía no llegó al punto de control.

**2. Entrada en régimen.** A los ~5 min de proceso simulado el sistema entra en `PROCESO`, la temperatura se estabiliza en 71.9 °C y la reducción logarítmica se dispara de 0 a 12 en apenas 90 segundos. Ahí se ve la sensibilidad brutal de Arrhenius con Ea = 357 kJ/mol.

**3. Provocar una desviación.** Baja el slider de temperatura a 68 °C. En segundos aparece la alarma `PCC-1` en rojo con su acción correctiva. Vuelve a 72 °C y muestra que la alarma no se limpia de inmediato: es la histéresis trabajando.

**4. Demostrar Arrhenius en vivo.** Compara el indicador "Vida media t½" a 65 °C y a 75 °C. Un salto de 10 °C cambia el valor en casi un orden de magnitud. Es la ecuación de Arrhenius hecha número en pantalla.

**5. Cambiar de proceso.** Selecciona fermentación y pulsa "Nuevo lote". Sube la aceleración a 300×. En unos 90 segundos de reloj real verás las 4.5 h de fermentación completas y la curva de pH cayendo de 6.6 a 4.6 con su forma característica.

---

## 6. Estructura de archivos

```
gemelo-digital-quimica/
├── README.md                    esta guía
├── requirements.txt
├── streamlit_app.py             dashboard alternativo
├── backend/
│   ├── config.py                constantes, perfiles y límites PCC
│   ├── chemistry.py             motor químico (puro, sin dependencias de red)
│   ├── alerts.py                evaluación HACCP con histéresis
│   ├── simulator.py             hilo de tiempo real y sensores IoT
│   └── app.py                   FastAPI + WebSocket
├── frontend/
│   └── index.html               tablero de operador (Chart.js)
├── docs/
│   └── trama_ejemplo.json       trama real capturada del sistema
└── tests/
    └── test_chemistry.py        20 pruebas contra soluciones analíticas
```

---

## 7. Cómo extenderlo

Si te sobra tiempo y quieres subir la nota, en orden de esfuerzo creciente:

**Añadir un proceso nuevo.** Copia un `ProcessProfile` en `config.py`, ajusta los parámetros y regístralo en el diccionario `PROFILES`. No hay que tocar nada más: aparece solo en el selector del tablero.

**Cambiar el control proporcional por un PID.** El lazo actual tiene error de offset permanente (T se estabiliza en 71.92 y no en 72.00 exactos). Añadir el término integral lo elimina, y explicar por qué existe ese offset es material de sustentación.

**Persistir los lotes.** Un `SQLite` con una tabla de tramas convertiría la bitácora de desviaciones en un registro HACCP auditable de verdad, que es como funciona en planta.

**Ajustar parámetros con datos reales.** Si tu compañero consigue una curva experimental de pH contra tiempo, `scipy.optimize.curve_fit` puede estimar A y Ea a partir de ella en lugar de usar los valores de literatura.
